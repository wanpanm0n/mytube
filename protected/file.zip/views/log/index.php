<?php
/* @var $this LogController */

$this->breadcrumbs=array(
	'Log',
);
?>
<h1>Under Construction</h1>

<p>
	You may change the content of this page by modifying
	the file <tt><?php echo __FILE__; ?></tt>.
</p>
