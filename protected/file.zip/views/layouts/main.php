<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Mtrading Mobile</title>
    <link href="<?php echo Yii::app()->request->baseurl; ?>/css/main.css" rel="stylesheet">
    <link href="<?php echo Yii::app()->request->baseurl; ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo Yii::app()->request->baseurl; ?>/css/sb-admin-2.css" rel="stylesheet">
    <!-- <link href="<?php //echo Yii::app()->request->baseurl; ?>/css/font-awesome.min.css" rel="stylesheet" type="text/css"> -->
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <?php 
    $cs = Yii::app()->clientScript;
    $cs->scriptMap = array(
    		'jquery.js' => Yii::app()->request->baseUrl.'/js/jquery.min.js',
    		//'jquery.yii.js' => Yii::app()->request->baseUrl.'/js/jquery.min.js',
    );
    $cs->registerCoreScript('jquery');
    ?>

</head>

<body>
    <div id="wrapper">
		<?php echo $content; ?>
    </div>
    <!-- /#wrapper -->
    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo Yii::app()->request->baseurl; ?>/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo Yii::app()->request->baseurl; ?>/js/metisMenu.min.js"></script>
        <script src="<?php echo Yii::app()->request->baseurl; ?>/js/mtrademobile.min.js"></script>

    <!-- Morris Charts JavaScript -->
<!--     <script src="../bower_components/raphael/raphael-min.js"></script> -->
<!--     <script src="../bower_components/morrisjs/morris.min.js"></script> -->
<!--     <script src="../js/morris-data.js"></script> -->

    <!-- Custom Theme JavaScript -->

</body>

</html>