<style>
body{
	background-color: #b95835 !important;
}
</style>
<?php /* @var $this Controller #c8202e */ ?>
<?php $this->beginContent('//layouts/main'); ?>
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
<!--                 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"> -->
<!--                     <span class="sr-only">Toggle navigation</span> -->
<!--                     <span class="icon-bar"></span> -->
<!--                     <span class="icon-bar"></span> -->
<!--                     <span class="icon-bar"></span> -->
<!--                 </button> -->
<!--                 <a class="navbar-brand" >MTrading Mobile</a> -->
            	<a href="<?php echo Yii::app()->request->baseUrl; ?>" class="navbar-brand"><img src="<?php echo Yii::app()->request->baseUrl; ?>/images/logo/logo_inverse.png" style="max-width: 50%; margin: -9px -7px 10px;"> </a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>(<?php echo Yii::app()->user->name; ?>)  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="<?php echo Yii::app()->request->baseUrl; ?>/user/profile"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
<!--                         <li><a href=""><i class="fa fa-gear fa-fw"></i> Settings</a> -->
<!--                         </li> -->
                        <li class="divider"></li>
                        <li><a href="<?php echo Yii::app()->request->baseUrl; ?>/user/logout"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
<!--                         <li> -->
<!--                             <a href="index.html"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a> -->
<!--                         </li> -->
                    
                    <?php if(!Yii::app()->user->isAdmin()){
                    ?>
                    	<li class='sidebar-search'>
                    		<h4>Language: <span class="label label-danger" style="font-size: 16px;"><?php echo Profile::getLanguage(); ?></span></h4>
                    	</li>
                    <?php 
					}?>
                        <?php 
                        if(Yii::app()->user->isAdmin()){
                        ?>
                        <li>
                            <a href="<?php echo Yii::app()->request->baseUrl; ?>/user/admin"><i class="fa fa-dashboard fa-fw"></i> Users</a>
                        </li>
                        <?php 
                        }
                        ?>
                         <?php 
                        if(Yii::app()->user->isAdmin()){
                        ?>
                        <li>
                            <a href="<?php echo Yii::app()->request->baseUrl; ?>/category/admin"><i class="fa fa-dashboard fa-fw"></i> Category</a>
                        </li>
                        <?php 
                        }
                        ?>
                        <?php if(!Yii::app()->user->isGuest && !Yii::app()->user->isAdmin()){?>
                        <li>
                            <a href="<?php echo Yii::app()->request->baseUrl; ?>/content"><i class="fa fa-dashboard fa-fw"></i> Contents</a>
                        </li>
                        <?php 
                        }
                        ?>
						<?php if(!Yii::app()->user->isGuest && !Yii::app()->user->isAdmin()){?>
                         <li>
                            <a href="<?php echo Yii::app()->request->baseUrl; ?>/notification/admin"><i class="fa fa-dashboard fa-fw"></i> Notifications</a>
                        </li>
                        <?php } ?>
                        <?php if(!Yii::app()->user->isGuest && !Yii::app()->user->isAdmin()){?>
                         <li>
                            <a href="<?php echo Yii::app()->request->baseUrl; ?>/feedback/admin"><i class="fa fa-dashboard fa-fw"></i> Feedbacks</a>
                        </li>
                        <?php } ?>
                        
                        <?php 
                        if(Yii::app()->user->isAdmin()){
                        ?>
                        <li>
                            <a href="<?php echo Yii::app()->request->baseUrl; ?>/videoStats/admin"><i class="fa fa-dashboard fa-fw"></i> Reports</a>
                        </li>
                        <?php 
                        }
                        ?>
<!--                         <li> -->
<!--                        <img src="/mtrademobile/images/logo/logo.png" style="max-width: 86%;margin: 10px 16px 10px;"> -->
<!--                        </li> -->
<!--                         <li> -->
<!--                             <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Charts<span class="fa arrow"></span></a> -->
<!--                             <ul class="nav nav-second-level"> -->
<!--                                 <li> -->
<!--                                     <a href="flot.html">Flot Charts</a> -->
<!--                                 </li> -->
<!--                                 <li> -->
<!--                                     <a href="morris.html">Morris.js Charts</a> -->
<!--                                 </li> -->
<!--                             </ul> -->
                            <!-- /.nav-second-level -->
<!--                         </li> -->
<!--                         <li> -->
<!--                             <a href="tables.html"><i class="fa fa-table fa-fw"></i> Tables</a> -->
<!--                         </li> -->
<!--                         <li> -->
<!--                             <a href="forms.html"><i class="fa fa-edit fa-fw"></i> Forms</a> -->
<!--                         </li> -->
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
        	<div class="container-fluid">
               <?php echo $content; ?>
            </div>
        </div>

<?php $this->endContent(); ?>