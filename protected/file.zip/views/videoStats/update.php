<div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Update Reports <?php //echo $model->id; ?></h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>

<div class="col-md-8">

<?php $this->renderPartial('_form', array('model'=>$model)); ?>
</div>