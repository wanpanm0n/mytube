<?php
// $this->pageTitle = Yii::app ()->name . ' - ' . UserModule::t ( "Login" );
// $this->breadcrumbs = array (
// UserModule::t ( "Login" )
// );
?>
<div class="row text-center" style="margin: 30px 0px -40px 0px">
	<img src="<?php echo Yii::app()->request->baseUrl; ?>/images/logo/logo.jpg" style="max-width: 28%" />
</div>

<!-- <h1><?php //echo UserModule::t("Login"); ?></h1>  -->

<?php if(Yii::app()->user->hasFlash('loginMessage')): ?>

<div class="success">
	<?php echo Yii::app()->user->getFlash('loginMessage'); ?>
</div>

<?php endif; ?>

<p><?php //echo UserModule::t("Please fill out the following form with your login credentials:"); ?></p>

<div class="row">
	<div class="col-md-4 col-md-offset-4">
		<div class="login-panel panel panel-red">
			<div class="panel-heading">
				<h3 class="panel-title">Please Sign In</h3>
			</div>
			<div class="panel-body">
<?php echo CHtml::beginForm(); ?>

	
	<?php echo CHtml::errorSummary($model, '','',array('class'=>'alert alert-danger')); ?>
	<fieldset>
		<?php //echo CHtml::activeLabelEx($model,'username'); ?>
		<div class="form-group">
		<?php echo CHtml::activeTextField($model,'username', array('class'=>'form-control','placeHolder'=>'Email'))?>
		</div>

		<?php //echo CHtml::activeLabelEx($model,'password'); ?>
		<div class="form-group">
		<?php echo CHtml::activePasswordField($model,'password', array('class'=>'form-control','placeHolder'=>'Password'))?>
<!-- 					<p class="hint"> -->
		<?php //echo CHtml::link(UserModule::t("Register"),Yii::app()->getModule('user')->registrationUrl); ?>  <?php //echo CHtml::link(UserModule::t("Lost Password?"),Yii::app()->getModule('user')->recoveryUrl); ?>
		</p>
		</div>
		<div class="checkBox rememberMe">
		<label><?php echo CHtml::activeCheckBox($model,'rememberMe'); ?>Remember Me</label>
		<?php //echo CHtml::activeLabelEx($model,'rememberMe'); ?>
	</div>

		<?php echo CHtml::submitButton(UserModule::t("Login"), array('class'=>'btn btn-lg btn-danger btn-block', 'style'=>'background-color:#C8202E')); ?>
	</fieldset>
	
<?php echo CHtml::endForm(); ?>
</div>
		</div>
	</div>
</div>
<!-- form -->


<?php
// $form = new CForm(array(
// 'elements'=>array(
// 'username'=>array(
// 'type'=>'text',
// 'maxlength'=>32,
// ),
// 'password'=>array(
// 'type'=>'password',
// 'maxlength'=>32,
// ),
// 'rememberMe'=>array(
// 'type'=>'checkbox',
// )
// ),

// 'buttons'=>array(
// 'login'=>array(
// 'type'=>'submit',
// 'label'=>'Login',
// ),
// ),
// ), $model);
?>
<!-- <div class="row"> -->
<!-- 	<div class="col-md-4 col-md-offset-4"> -->
<!-- 		<div class="login-panel panel panel-default"> -->
<!-- 			<div class="panel-heading"> -->
<!-- 				<h3 class="panel-title">Please Sign In</h3> -->
<!-- 			</div> -->
<!-- 			<div class="panel-body"> -->
<!-- 				<form role="form"> -->
<!-- 					<fieldset> -->
<!-- 						<div class="form-group"> -->
<!-- 							<input class="form-control" placeholder="E-mail" name="email" -->
<!-- 								type="email" autofocus> -->
<!-- 						</div> -->
<!-- 						<div class="form-group"> -->
<!-- 							<input class="form-control" placeholder="Password" -->
<!-- 								name="password" type="password" value=""> -->
<!-- 						</div> -->
<!-- 						<div class="checkbox"> -->
<!-- 							<label> <input name="remember" type="checkbox" -->
<!-- 								value="Remember Me">Remember Me -->
<!-- 							</label> -->
<!-- 						</div> -->
<!-- Change this to a button or input when using this as a form -->
<!-- 						<a href="index.html" class="btn btn-lg btn-success btn-block">Login</a> -->
<!-- 					</fieldset> -->
<!-- 				</form> -->
<!-- 			</div> -->
<!-- 		</div> -->
<!-- 	</div> -->
<!-- </div> -->
