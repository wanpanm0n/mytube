<?php

return array(
	'Model Name'=>'Nombre del modelo',
	'Lable field name'=>'Nombre del campo lable',
	'Empty item name'=>'Vider nom de l\'article',
	'Profile model relation name'=>'Modelo de perfil respecto nombre',
);
